var languagesArrayCreation = function () {

  return 'A compléter';
}

var numbersArrayCreation = function () {

    return 'A compléter';
}

var ElementReplacement = function (languages) {

  return 'A compléter';
}

var AddElementToLanguagesArray = function (languages) {

  return 'A compléter';
}

var AddElementToNumbersArray = function (numbers) {

  return 'A compléter';
}

var deleteArrayFirstElement = function (languages) {

  return 'A compléter';
}

var deleteArrayLastElement = function (languages) {

  return 'A compléter';
}

var stringToArray = function (socialMediaInString) {

  return 'A compléter';
}

var arrayToString = function (languages) {

  return 'A compléter';
}

var arraySort = function (socialMedia) {

  return 'A compléter';
}

var arrayInvert = function (languages){


  return 'A compléter';
}
